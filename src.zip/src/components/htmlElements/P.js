function RenderP(props){
    // let arr=[]
    // for(let i=0; i<props.num;i++){
    // arr.push(props.num)
    // }
    // let divList=arr.map(elem=><props.tage/>)
  
        return(
            <>
            {console.log(props.tage)}
           {props.tage}
            </>
         )
    }
export default RenderP