import Div from "../htmlElements/Div"
export default function Footer(){
    return (
        <Div num={1} class='footer'/>
    )
}