
import './Header.css';

function App() {
  return (
    <header className="App-header">
      <ul className="Ul">
        <li>Logo</li>
      </ul>
      <ul className="Ul">
        <li>Home</li>
        <li>About</li>
        <li>Contact</li>
      </ul>
      </header>

  );
}

export default App;
